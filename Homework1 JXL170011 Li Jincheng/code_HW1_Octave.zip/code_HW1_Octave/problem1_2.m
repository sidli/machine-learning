data = load("perceptron.data"); 

X = data(:, 1:4);
Y = data(:, 5);
[m, n] = size(X);

w = [0; 0; 0; 0];
b = 0;

learning_step = 1;

k = 1;
counter1 = 0;
counter2 = 0;
counter3 = 0;
run = 1;

while run <= m

  x = X(k,:);
  y = Y(k);
  
  %Slearning_step = (1/ (0.9 + (0.1 * counter2)));
  counter2 = counter2 + 1;
  
  if (((x * w) .+ b) .* (-y)) >= 0
    run = 0;
    counter1 = counter1 + 1;
    w = w .+ (learning_step * (y * x))';
    b = b .+ (learning_step * (y));
    yxwb = (X * w .+ b) .* (-Y);
    mask = (yxwb >= 0);
    loss = sum(yxwb .* mask);
    disp ("counter1: "), disp(counter1);
    disp ("counter2: "), disp(counter2);
    disp ("counter3: "), disp(counter3);
    disp ("learning step: "), disp(learning_step);
    disp ("w:        "), disp(w');
    disp ("b:        "), disp(b);
    disp ("loss:     "), disp(loss);
    disp ("-------------------");
  else
    run = run + 1;
    counter3 = counter3 + 1;
  end
  
  k = mod(k, m) + 1;
end