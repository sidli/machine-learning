data = load("perceptron.data"); 

X = data(:, 1:4);
Y = data(:, 5);



w = [0; 0; 0; 0];
b = 0;
learning_step = 1;
counter = 0;

yxwb = (X * w .+ b) .* (-Y);
mask = (yxwb >= 0);
dw = X' * ((-Y) .* mask);
db = sum((-Y) .* mask);

while (sum(abs(dw)) + abs(db) ~= 0)
  
  %learning_step = (1/ (0.9 + (0.1 * counter)));
  counter = counter + 1; 
  yxwb = (X * w .+ b) .* (-Y);
  mask = (yxwb >= 0);
  loss = sum(yxwb .* mask);
  
  disp ("counter: "), disp(counter);
  disp ("w:       "), disp(w');
  disp ("b:       "), disp(b);
  disp ("loss:    "), disp(loss);
  disp ("-------------------");
  
  dw = X' * ((-Y) .* mask);
  db = sum((-Y) .* mask);
  
  w = w - (learning_step .* dw); # vector 4x1
  b = b - (learning_step .* db);     # number
  
end
 
