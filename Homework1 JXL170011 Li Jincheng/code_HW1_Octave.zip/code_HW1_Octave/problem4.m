%This is Octave code.
%first, you should install prim package for quadprog function.
%install it:  pkg install pkgName.tar.tz
%load it:     pkg load prime 
%
data = load("mystery.data"); 
% setting degrees
k = 2;

X = data(:, 1:4);
Y = data(:, 5);
[m, n] = size(X);

% creating new feature space by degree k 

coefs = zeros(0, n);
for(d = 1:k)
    coefs = [coefs; mg_sums(n, d)];
end

coefX = zeros(m, size(coefs, 1));
for(i = 1:size(coefs, 1))
    accumulator = ones(m, 1);
    for(j = 1:n)
        accumulator = accumulator .* (X(:, j) .^ coefs(i, j));
    end
    coefX(:, i) = accumulator;
end

new_X = [ones(m, 1), coefX];
[m, n] = size(new_X);

% Change our parameters to fit to the quadprog function 
H = eye(n)*2;
H(1,1) = 0;
f = zeros(n ,1);
A = (-Y) .* (new_X);
b = ones(m, 1) .* (-1);

%quadprog function 
w = quadprog(H, f, A, b);
%w = qp(H, f, A, b);


% Computing loss for all data point. 
est = new_X * w;
yxwb = (est) .* (-Y);
mask = (yxwb >= 0);
loss = sum(yxwb .* mask);

margin = min(abs(est))/(w'*w);


[_, n] = size(coefs);
disp([[zeros(1, n);coefs], w]);

%disp(w);
disp(sum(mask));
disp(margin);
disp(min(abs(est)));