import numpy as np

def loadDataSet(filename):
    dataMat=[]
    labelMat=[]
    fr = open(filename)
    for line in fr.readlines():
        lineArr=line.strip().split(',')
        dataMat.append([float(lineArr[0]),float(lineArr[1]),float(lineArr[2]),float(lineArr[3])])
        labelMat.append(float(lineArr[4]))
    return dataMat,labelMat

def smo(dataArr, labelArr): 
    iteration = 0
    length = len(dataArr)
    gradation = 4
    a = [0 for i in range(length)]
        
def main():
    dataArr,labelArr = loadDataSet("mystery.data")
    smo(dataArr, labelArr) 

if __name__ == '__main__':
    main()
