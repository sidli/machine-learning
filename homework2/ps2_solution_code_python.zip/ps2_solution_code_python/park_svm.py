

import csv
from cvxopt import matrix, solvers
from numpy import array, zeros, ones, identity, diag, dot, absolute, sqrt, vstack, hstack


# read in data
def read_data(filename):
    with open(filename) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')

        x, y = [], []
        num_data = 0
        for row in csv_reader:
            temp = int(row[0])
            if temp == 0:
                y.append(-1)
            else:
                y.append(1)
            x.append([1.0]) # 1.0 is the constant term
            for data in row[1:]:
                x[num_data].append(float(data))
            num_data += 1
    return array(x), array(y)



# standard form is: min 1/2 x^T P x + q^T x
# subject to: Gx <= h
"""
def cvxopt_solve_qp(P, q, G=None, h=None, A=None, b=None):
    P = .5 * (P + P.T)  # make sure P is symmetric
    args = [matrix(P, tc='d'), matrix(q, tc='d')]
    if G is not None:
        args.extend([matrix(G, tc='d'), matrix(h, tc='d')])
        if A is not None:
            args.extend([matrix(A, tc='d'), matrix(b, tc='d')])
    solvers.options['show_progress'] = False
    sol = solvers.qp(*args)
    return array(sol['x']).reshape((P.shape[1],))
"""
def cvxopt_solve_qp(P, q, G=None, h=None, A=None, b=None):
    P = .5 * (P + P.T)  # make sure P is symmetric
    dim = P.shape[1]
    P = matrix(P, tc='d')
    q = matrix(q, tc='d')
    if G is not None:
        G = matrix(G, tc='d')
        h = matrix(h, tc='d')
    if A is not None:
        A = matrix(A, tc='d')
        b = matrix(b, tc='d')
    solvers.options['show_progress'] = False
    sol = solvers.qp(P, q, G, h, A, b)
    #print(sol)
    return array(sol['x']).reshape(dim)


def accuracy(w, x, y):
    # w contains [b w \xi]^T, w[:dimension] is [b w]^T
    y_hypo = dot(x, w[:dimension])
    count = 0
    for i in range(len(y_hypo)):
        if y_hypo[i] * y[i] > 0:
            count += 1
    return count/num_data


# if there is a tie, should pick the largest c
def bestc_index(accuracy_list):
    max_accuracy = 0
    index = 0
    for i in range(len(accuracy_list)):
        if accuracy_list[i] >= max_accuracy:
            max_accuracy = accuracy_list[i]
            index = i
    return index


# construct the parameters for cvxopt solver
x_train, y_train = read_data('park_train.data')
x_vali, y_vali = read_data('park_validation.data')
x_test, y_test = read_data('park_test.data')
num_data, dimension = x_train.shape

P = diag([0] + [1] * (dimension - 1) + [0] * num_data)

def q(c):
    return array([0] * dimension + [c] * num_data)

G_1 = -y_train.reshape(num_data, 1) * x_train
G_2 = diag([-1] * num_data)
G_3 = zeros([num_data, dimension])
G_4 = diag([-1] * num_data)
G = vstack([hstack([G_1, G_2]), hstack([G_3, G_4])])

h = array([-1] * num_data + [0] * num_data)


# generate parameter list
c_list = []
for i in range(9):
    c_list.append(10**i)



def main():

    print('Primal SVM')
    print('_' * 80)
    ################################################################
    print('Accuracy of the learned classifier on the training set: ')
    w_dict = {}
    for c in c_list:
        w = cvxopt_solve_qp(P, q(c), G, h)
        w_dict[c] = w
        print(f'c = {c:9}, accuracy is: {accuracy(w, x_train, y_train)}')

    print('_'*80)
    input("Press Enter to continue...")

    ################################################################
    print('Accuracy on the validation set: ')
    para_list = []
    max_accu = 0
    for c in c_list:
        accu = accuracy(w_dict[c], x_vali, y_vali)
        para_list.append([c, accu])
        print(f'c = {c:9}, accuracy is: {accu}')
        if accu > max_accu:
            max_accu = accu

    print(f'Max accuracy on validation set is: {max_accu}')

    best_c_list = []
    for para in para_list:
        if para[1] == max_accu:
            best_c_list.append(para[0])
    print('_' * 80)
    input("Press Enter to continue...")

    ################################################################
    print(f'Accuracy on test set: ')
    for c in best_c_list:
        print(f'c = {c:3}, accuracy = {accuracy(w_dict[c], x_test, y_test)}')



if __name__ == '__main__':
    main()