

import csv
from cvxopt import matrix, solvers
from numpy import array, zeros, ones, identity, diag, dot, exp, mean, average, absolute, sqrt, vstack, hstack


# read in data
def read_data(filename):
    with open(filename) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')

        x, y = [], []
        num_data = 0
        for row in csv_reader:
            temp = int(row[0])
            if temp == 0:
                y.append(-1)
            else:
                y.append(1)
            x.append([])
            for data in row[1:]:
                x[num_data].append(float(data))
            num_data += 1
    return array(x), array(y)


# standard form is: min 1/2 x^T P x + q^T x
# subject to: Gx <= h
#              Ax = b
def cvxopt_solve_qp(P, q, G=None, h=None, A=None, b=None):
    P = .5 * (P + P.T)  # make sure P is symmetric
    dim = P.shape[1]
    P = matrix(P, tc='d')
    q = matrix(q, tc='d')
    if G is not None:
        G = matrix(G, tc='d')
        h = matrix(h, tc='d')
    if A is not None:
        A = matrix(A, tc='d')
        b = matrix(b, tc='d')
    solvers.options['show_progress'] = False
    sol = solvers.qp(P, q, G, h, A, b)
    #print(sol)
    return array(sol['x']).reshape(dim)


def gaussian_kernel(x, sigma):
    # x is a matrix
    m = x.shape[0]
    gaussian_M = zeros((m, m))
    for i in range(m):
        for j in range(m):
            gaussian_M[i][j] = gaussian(x[i], x[j], sigma)
    return gaussian_M


def gaussian(x, z, sigma):
    return exp(-dot(x-z, x-z)/(2*sigma**2))


# construct the parameters for cvxopt solver
x_train, y_train = read_data('park_train.data')
x_vali, y_vali = read_data('park_validation.data')
x_test, y_test = read_data('park_test.data')
num_data, dimension = x_train.shape


kernel = gaussian_kernel(x_train, 1)
#kernel = dot(x_train, x_train.T)
temp = dot(diag(y_train), kernel)
P = dot(temp, diag(y_train))

q = -ones(num_data)
G = vstack([-identity(num_data), identity(num_data)])
def h(c):
    return vstack([zeros((num_data, 1)), c * ones((num_data, 1))])
A = y_train.reshape((1, num_data))
b = 0



# lamda(c) returns the learned lamda with parameter c
def lamda(c):
    return cvxopt_solve_qp(P, q, G, h(c), A, b)


# generating parameter lists
c_list = []
for i in range(9):
    c_list.append(10**i)

sigma_list = []
for i in range(5):
    sigma_list.append(10**(i-1))


# hypo returns result for a test x with sigma
def hypo(x, lam, sigma):
    result = 0
    for i in range(num_data):
        result += lam[i] * y_train[i] * gaussian(x_train[i], x, sigma)
    return result


# x
def accuracy(x, y, lam, sigma):
    count = 0
    m = len(y)
    for i in range(m):
        if hypo(x[i], lam, sigma) * y[i] > 0:
            count += 1
    return count/m






def main():

    print('Dual SVM with Gaussian Kernels')
    print('_' * 80)
    #######################################################################
    print('Accuracy on training set: ')
    lam_dic = {}
    for c in c_list:
        lam = lamda(c)
        lam_dic[c] = lam
        for sigma in sigma_list:
            accu = accuracy(x_train, y_train, lam, sigma)
            print(f'c = {c:9}, sigma = {sigma:4}, '
                  f'accuracy = {accu}')
    print('_' * 80)
    input("Press Enter to continue...")

    #######################################################################

    print('Accuracy on validation set: ')
    para_list = []
    max_accu = 0
    for c in c_list:
        lam = lam_dic[c]
        for sigma in sigma_list:
            accu = accuracy(x_vali, y_vali, lam, sigma)
            if accu > max_accu:
                max_accu = accu
            print(f'c = {c:9}, sigma = {sigma:4}, '
                  f'accuracy = {accu}')
            para_list.append([c, sigma, accu])

    print(f'Max accuracy on validation set is: {max_accu}')

    best_para_list = []
    for para in para_list:
        if para[2] == max_accu:
            best_para_list.append(para)

    print('_' * 80)
    input("Press Enter to continue...")

    #######################################################################

    print('Accuracy on test set: ')

    for para in best_para_list:
        c = para[0]
        lam = lam_dic[c]
        sigma = para[1]
        accu = accuracy(x_test, y_test, lam, sigma)
        print(f'c = {c:9}, sigma = {sigma:4}, '
                f'accuracy = {accu}')



def main2():
    # this is for the report in latex
    print('Dual SVM with Gaussian Kernels')
    print('_' * 80)
    #######################################################################
    print('Accuracy on training set: ')
    lam_dic = {}
    for c in c_list:
        lam = lamda(c)
        lam_dic[c] = lam
        for sigma in sigma_list:
            accu = accuracy(x_train, y_train, lam, sigma)
            print(f'c = {c:9}, \\; \sigma = {sigma:4}, \\; '
                  f'& \\accuracy = {accu}\\\\')
    print('_' * 80)
    input("Press Enter to continue...")

    #######################################################################

    print('Accuracy on validation set: ')
    para_list = []
    max_accu = 0
    for c in c_list:
        lam = lam_dic[c]
        for sigma in sigma_list:
            accu = accuracy(x_vali, y_vali, lam, sigma)
            if accu > max_accu:
                max_accu = accu
            print(f'c = {c:9}, \\; \sigma = {sigma:4}, \\; '
                  f'& \\accuracy = {accu}\\\\')
            para_list.append([c, sigma, accu])

    print(f'Max accuracy on validation set is: {max_accu}')

    best_para_list = []
    for para in para_list:
        if para[2] == max_accu:
            best_para_list.append(para)

    print('_' * 80)
    input("Press Enter to continue...")

    #######################################################################

    print('Accuracy on test set: ')

    for para in best_para_list:
        c = para[0]
        lam = lam_dic[c]
        sigma = para[1]
        accu = accuracy(x_test, y_test, lam, sigma)
        print(f'c = {c:9}, \\; \sigma = {sigma:4}, \\; '
              f'& \\accuracy = {accu}\\\\')

if __name__ == '__main__':
    main()