

import csv
import numpy as np


def read_data(filename):
    data = []
    with open(filename) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        for row in csv_reader:
            data.append(row)
    return np.array(data)

data_train = read_data('mush_train.data')
#data_train = read_data('test.data')
data_test = read_data('mush_test.data')
num_data, num_feature = data_train.shape
num_feature -= 1



def log(x):
    if x == 0:
        return 0.0
    else:
        return np.log(x)


def entropy(y):
    l = list(y)
    total = len(l)
    result = 0
    for s in set(l):
        p = l.count(s)/total
        result += p * log(p)
    return -result


def info_gain(data, feature_index):
    hy = entropy(data[:, 0])
    #print(f'H(Y) = {hy}')
    hy_x = 0
    x_arr = data[:, feature_index]
    for x in set(x_arr):
        px = list(x_arr).count(x)/len(x_arr)
        x_index = np.where(x_arr == x)[0]
        y = data[x_index, 0]
        p = px * -entropy(y)
        #print(f'p = {p}')
        hy_x -= p
    #print(f'H(Y|X) = {hy_x}')
    return hy - hy_x


class Node:
    def __init__(self, index, name, depth, data, max_depth=np.infty):
        self.index = index  # this is the index from which to make the partition
        self.name = name
        self.depth = depth
        self.data = data
        self.max_depth = max_depth
        # the feature_index is the index to make the next level of partition
        self.max_info_gain, self.feature_index = self.find_gain_index()
        self.children = self.find_children()

    def __repr__(self):
        return f'({self.index}, {self.name})[depth {self.depth}]-> {self.feature_index}'

    def find_gain_index(self):
        max_gain = -1.0
        feature_index = -1
        for i in range(1, num_feature + 1):
            gain = info_gain(self.data, i)
            if gain >= max_gain:
                max_gain = gain
                feature_index = i
        # if the max information gain is 0, return feature_index as -1
        # which means it is a leave node
        if np.isclose(max_gain, 0.0):
            feature_index = -1
        #print(feature_index, set((data_train[:, i])))
        return max_gain, feature_index

    def find_children(self):
        # if the current data set has only one label, stop
        # or if the max information gain is 0, stop
        if len(set(self.data[:, 0])) == 1 \
                or np.isclose(self.max_info_gain, 0.0) \
                or self.depth >= self.max_depth:
            return None
        else:
            children = []
            feature_arr = self.data[:, self.feature_index]
            children_names = list(set(feature_arr))
            for name in children_names:
                child_data = self.data[np.where(feature_arr == name)[0], :]
                new_child = Node(self.feature_index, name, self.depth + 1, child_data, self.max_depth)
                children.append(new_child)
                #print(self.feature_index, children)
            return children

    def find_label(self):
        labels = list(self.data[:, 0])
        e_count = labels.count('e')
        p_count = labels.count('p')
        if e_count > p_count:
            return 'e'
        else:
            return 'p'


def print_tree(node):
    global node_count, tree_depth
    print(node)
    node_count += 1
    if node.depth > tree_depth:
        tree_depth = node.depth

    if node.children is not None:
        for child in node.children:
            print_tree(child)


def hypo(node, data_arr):
    name = data_arr[node.feature_index]
    if node.children is None:
        return node.find_label()
    else:
        for child_node in node.children:
            if child_node.name == name:
                return hypo(child_node, data_arr)
        # if name is not in the children node name list,
        # return the label of current partition
        return node.find_label()


def accuracy(root, data):
    size = data.shape[0]
    count = 0
    for data_arr in data:
        if hypo(root, data_arr) == data_arr[0]:
            count += 1
    return count/size


def check_one_level():
    label_train = data_train[:, 0]
    label_test = data_test[:, 0]
    test_count = data_test.shape[0]
    accu = []
    for feature_index in range(1, num_feature + 1):
        hypo_dict = {}
        feature_data = data_train[:, feature_index]
        children_names = np.unique(feature_data)
        for name_index in range(len(children_names)):
            name = children_names[name_index]
            data_indices = list(np.where(feature_data == name)[0])
            e_count, p_count = 0, 0
            for index in data_indices:
                if label_train[index] == 'e':
                    e_count += 1
                else:
                    p_count += 1
            if e_count > p_count:
                hypo_dict[name] = 'e'
            else:
                hypo_dict[name] = 'p'
        #print(feature_index, hypo_dict)
        feature_data_test = data_test[:, feature_index]
        count = 0
        for data_index in range(len(feature_data_test)):
            data = feature_data_test[data_index]
            if label_test[data_index] == hypo_dict[data]:
                count += 1
        accu.append(count/test_count)
    return accu





def main():

    root = Node(index=0, name='root', depth=0, data=data_train, max_depth=5)
    global node_count, tree_depth
    node_count, tree_depth = 0, 0
    print_tree(root)
    print(f'node_count = {node_count}, tree_depth = {tree_depth}')
    print(f'Accuracy on training set is: {accuracy(root, data_train)}')
    print(f'Accuracy on test set is: {accuracy(root, data_test)}')

    print('_' * 80)
    input("Press Enter to continue...")
    print("Accuracy list with exactly one non-leaf node:")

    accu_list = check_one_level()
    for i in range(len(accu_list)):
        print(f'feature: {i + 1}, with accuracy: {accu_list[i]}')


if __name__ == '__main__':
    main()

