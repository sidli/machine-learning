

import csv
from numpy import array, dot, sqrt


# read in data
def read_data(filename):
    with open(filename) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')

        x, y = [], []
        num_data = 0
        for row in csv_reader:
            temp = int(row[0])
            if temp == 0:
                y.append(-1)
            else:
                y.append(1)
            x.append([])
            for data in row[1:]:
                x[num_data].append(float(data))
            num_data += 1
    return array(x), array(y)


# x1 and x2 are arrays
def distance(x1, x2):
    return sqrt(dot(x1 - x2, x1 - x2))


# returns a distance_label list sorted by distance
def distance_label(x):
    dl_list = []
    for i in range(num_data):
        dl_list.append([distance(x_train[i], x), y_train[i]])
    return sorted(dl_list, key=lambda l: l[0])


# input a data x, return its label
def hypo(x, k):
    distance_list = distance_label(x)
    #print(distance_list)
    pos, neg = 0, 0
    for i in range(k):
        if distance_list[i][1] == 1:
            pos += 1
        else:
            neg += 1
    #print(pos, neg)
    if pos > neg:
        return 1
    else:
        return -1

# input x matrix and k, return accuracy
def accuracy(xm, k):
    count = 0
    num = xm.shape[0]
    for i in range(num):
        if hypo(xm[i], k) == y_train[i]:
            count += 1
    return count/num




x_train, y_train = read_data('park_train.data')
x_vali, y_vali = read_data('park_validation.data')
x_test, y_test = read_data('park_test.data')
num_data, dimension = x_train.shape

k_list = [1, 5, 11, 15, 21]


def main():

    print('K-nearest neighbor')
    print('_' * 80)
    #######################################################################
    print('Accuracy on training set: ')
    for k in k_list:
        print(f'k = {k:2}, accuracy = {accuracy(x_train, k)}')

    print('_' * 80)
    input("Press Enter to continue...")

    #######################################################################
    print('Accuracy on validation set: ')
    max_accu = 0
    para_list = []
    for k in k_list:
        accu = accuracy(x_vali, k)
        print(f'k = {k:2}, accuracy = {accu}')
        if accu > max_accu:
            max_accu = accu
        para_list.append([k, accu])

    print(f'Max accuracy on validation set is: {max_accu}')

    best_k_list = []
    for para in para_list:
        if para[1] == max_accu:
            best_k_list.append(para[0])

    print('_' * 80)
    input("Press Enter to continue...")

    #######################################################################
    print('Accuracy on test set: ')

    for k in best_k_list:
        print(f'k = {k:2}, accuracy = {accuracy(x_test, k)}')




def main2():
    # this is for the report in latex

    print('K-nearest neighbor')
    print('_' * 80)
    #######################################################################
    print('Accuracy on training set: ')
    for k in k_list:
        print(f'k = {k:2}, \\; & \\accuracy = {accuracy(x_train, k)}')

    print('_' * 80)
    input("Press Enter to continue...")

    #######################################################################
    print('Accuracy on validation set: ')
    max_accu = 0
    para_list = []
    for k in k_list:
        accu = accuracy(x_vali, k)
        print(f'k = {k:2}, \\; & \\accuracy = {accu}')
        if accu > max_accu:
            max_accu = accu
        para_list.append([k, accu])

    print(f'Max accuracy on validation set is: {max_accu}')

    best_k_list = []
    for para in para_list:
        if para[1] == max_accu:
            best_k_list.append(para[0])

    print('_' * 80)
    input("Press Enter to continue...")

    #######################################################################
    print('Accuracy on test set: ')

    for k in best_k_list:
        print(f'k = {k:2}, \\; & \\accuracy = {accuracy(x_test, k)}')


if __name__ == '__main__':
    main()